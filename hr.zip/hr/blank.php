<?php
require_once('../private/initialize.php');

$page = 'Blank';
$page_title = 'Blank';
include(SHARED_PATH . '/header.php');

?>

<?php include (SHARED_PATH . '/footer.php') ?>